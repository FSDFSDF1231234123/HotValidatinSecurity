# Changelog

## 1.1.2

- Fix current theme directory retrieval ([@jf-viguier](https://github.com/jf-viguier))

## 1.1.1

- Fix renew password form turnstile error

## 1.1.0

- Prestashop 8.0.0 compatibility

## 1.0.3

- Custom or third party form validation

## 1.0.2

- Action option added

## 1.0.1

- Display full error messages instead of error codes
- PHPDoc updated

## 1.0.0

- First stable release